# Telegram Essay Bot for Railway

## Шаги запуска

1. Создай новый проект в Railway.
2. Залей этот проект (через ZIP upload).
3. В разделе **Variables** добавь переменные:
   - BOT_TOKEN
   - OPENAI_API_KEY
   - TEXTRU_API_KEY (опционально)

4. Railway автоматически обнаружит `Procfile`.
5. Нажми Deploy — бот запустится.

Работает через long polling, вебхуки не нужны.
